# lib
Android Gradle library.
Most of the android legacy code will go here.
(some will go to ../core/lib pure Java library)

# demo
Thin client.

# lib-core
The core java library used as a dependency.
