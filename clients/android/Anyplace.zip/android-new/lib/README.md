# Anyplace Android Gradle library
This library is used to create the [Demo Client](./demo/)
