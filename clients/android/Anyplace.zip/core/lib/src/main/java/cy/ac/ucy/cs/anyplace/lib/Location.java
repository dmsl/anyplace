package cy.ac.ucy.cs.anyplace.lib;

public class Location {
    String lat;
    String lon;
}
