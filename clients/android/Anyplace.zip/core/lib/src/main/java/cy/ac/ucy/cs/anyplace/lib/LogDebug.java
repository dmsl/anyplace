package cy.ac.ucy.cs.anyplace.lib;

public class LogDebug {

    private static final String TAG = "android-core";
    enum Level{
        ERR,
        WARN,
        DEBUG,
        DEBUG2
    };



}
