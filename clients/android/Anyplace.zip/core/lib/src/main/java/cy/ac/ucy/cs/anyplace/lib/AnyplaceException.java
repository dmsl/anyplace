package cy.ac.ucy.cs.anyplace.lib;

public class AnyplaceException extends Exception {


    public AnyplaceException(String message, Throwable cause) {
        super(message, cause);


    }


}
