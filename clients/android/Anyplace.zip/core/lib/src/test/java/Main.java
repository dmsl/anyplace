import org.junit.runner.JUnitCore;

public class Main {

    public static void main(String[] args){
        JUnitCore.runClasses(TesterPreferences.class);
        System.out.println("Run with tester Preferences");
    }
}
