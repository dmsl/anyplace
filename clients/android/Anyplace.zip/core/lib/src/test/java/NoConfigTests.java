public interface NoConfigTests {
}
