*TESTING:
    - Junit tests
    - Added the Tester class to the src/test/java dir 
    
*EXCEPTION HANDLING:
    - Handle all exceptions in Anyplace.java and return json strings
    
*RETURN OF VALUES:
    - json by default that contains a status code
   
*CODE CLEANUP
    - Cleanup of Anyplace.java
    
*SETTINGS FILES FOR SERVER SETTINGS AND API KEY
    - Can be read from ~/.anyplace/ or from a specified file
    - Added the necessary methods to Anyplace.java to support calls with the loaded settings.